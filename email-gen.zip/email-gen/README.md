## Install EmailGen from Repository
Clone repository:
```
git clone https://bitbucket.berenberg.io/scm/dsc/email-gen.git
```

- This will clone the repository on your local machine. Navigate to the newly created folder.

**INSTALL DEPENDENCIES**

```
npm install
```

**START WORKFLOW**

- We are ready to start our development server with the command:
```
npm run dev
```

### Templating and HTML Partials
To avoid repetitive HTML code, EmailGen uses [gulp-file-include](https://github.com/haoxins/gulp-file-include). It has a simple templating synthax and allows to re-use chunks of code written in separate files. These partials are located in the directory:
```
src/includes/
```

For more information check out their documentation and examples: https://github.com/haoxins/gulp-file-include 


### Production
To build the production templates:
```
npm run prod
```

All styles will be inlined 🚀

---

**Credits:**
- EmailGen is based on the FuzzyMail Generator https://github.com/luangjokaj/fuzzymail