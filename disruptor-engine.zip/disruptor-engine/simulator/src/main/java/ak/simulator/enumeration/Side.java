package ak.simulator.enumeration;

/**
 * The Side of an Order
 */
public enum Side {

    BUY,
    SELL
}
