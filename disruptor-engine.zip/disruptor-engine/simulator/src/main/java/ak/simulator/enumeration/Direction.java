package ak.simulator.enumeration;

/**
 * The Direction of a Position
 */
public enum Direction {

    LONG, SHORT, FLAT

}
