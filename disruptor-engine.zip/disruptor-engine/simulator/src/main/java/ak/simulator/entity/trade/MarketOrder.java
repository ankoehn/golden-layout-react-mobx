package ak.simulator.entity.trade;

import ak.simulator.enumeration.Side;

/**
 * A Market Order
 */
public class MarketOrder extends Order {

    public MarketOrder(Side side, long quantity) {
        super(side, quantity);
    }

    @Override
    public String toString() {
        return "MarketOrder [getSide()=" + getSide() + ", getQuantity()=" + getQuantity() + "]";
    }


}
