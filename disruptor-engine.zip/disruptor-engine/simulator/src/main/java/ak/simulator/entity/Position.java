package ak.simulator.entity;

import ak.simulator.enumeration.Direction;
import lombok.Getter;
import lombok.Setter;

/**
 * Represents an open position
 */
public class Position {

    @Getter @Setter
    private long quantity;
    @Getter @Setter
    private double cost;
    @Getter @Setter
    private double realizedPL;

    public double getAveragePrice() {

        return getCost() / getQuantity();
    }

    public Direction getDirection() {

        if (getQuantity() < 0) {
            return Direction.SHORT;
        } else if (getQuantity() > 0) {
            return Direction.LONG;
        } else {
            return Direction.FLAT;
        }
    }

    @Override
    public String toString() {
        return "Position [quantity=" + this.quantity + ", cost=" + this.cost + ", realizedPL=" + this.realizedPL + "]";
    }

}
