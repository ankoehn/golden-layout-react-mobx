package ak.simulator.enumeration;

/**
 * A Type of a Transaction
 */
public enum TransactionType {

    BUY, SELL

}
