package ak.simulator.simulation;

import ak.simulator.entity.Position;
import ak.simulator.entity.trade.MarketOrder;

public interface Simulator {

    void clear();

    void setCashBalance(double amount);

    double getCashBalance();

    void setCurrentPrice(double price);

    void sendOrder(MarketOrder order);

    Position getPosition();

}
