package ak.simulator.entity;

import ak.simulator.enumeration.TransactionType;
import lombok.Getter;
import lombok.Setter;

/**
 * A Transaction that took place as a result of an executed Order
 */
public class Transaction {

    @Getter @Setter
    private long quantity;
    @Getter @Setter
    private double price;
    @Getter @Setter
    private TransactionType type;

    public double getValue() {
        return -quantity * price;
    }

    @Override
    public String toString() {
        return "Transaction [quantity=" + this.quantity + ", price=" + this.price + "]";
    }

}
