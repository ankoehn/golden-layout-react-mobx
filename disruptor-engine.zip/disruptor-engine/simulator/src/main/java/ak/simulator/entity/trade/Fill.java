package ak.simulator.entity.trade;

import ak.simulator.enumeration.Side;
import lombok.Getter;
import lombok.Setter;

public class Fill {

    @Getter @Setter
    private Side side;
    @Getter @Setter
    private long quantity;
    @Getter @Setter
    private double price;
    @Getter @Setter
    private Order order;

    @Override
    public String toString() {
        return "Fill [side=" + this.side + ", quantity=" + this.quantity + ", price=" + this.price + "]";
    }
}
