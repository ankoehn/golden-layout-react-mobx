package ak.simulator.simulation;

import lombok.Getter;
import lombok.Setter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import ak.simulator.entity.Position;
import ak.simulator.entity.Transaction;
import ak.simulator.entity.trade.MarketOrder;
import ak.simulator.enumeration.Side;
import ak.simulator.enumeration.TransactionType;
import ak.simulator.util.PositionUtil;

/**
 * Utility that can be used by strategies during in-memory simulations.
 */
public class SimulatorImpl implements Simulator {

    private static Logger logger = LogManager.getLogger(SimulatorImpl.class.getName());

    @Getter @Setter private double cashBalance;
    @Setter private double currentPrice;
    @Getter private Position position;

    public void clear() {
        this.cashBalance = 0.0;
        this.currentPrice = 0.0;
        this.position = null;
    }

    public void sendOrder(MarketOrder order) {

        TransactionType transactionType = Side.BUY.equals(order.getSide()) ? TransactionType.BUY : TransactionType.SELL;
        long quantity = Side.BUY.equals(order.getSide()) ? order.getQuantity() : -order.getQuantity();

        Transaction transaction = new Transaction();
        transaction.setQuantity(quantity);
        transaction.setPrice(currentPrice);
        transaction.setType(transactionType);

        if (this.position == null) {

            // create a new position if necessary
            this.position = PositionUtil.processFirstTransaction(transaction);

        } else {

            // process the transaction (adjust quantity, cost and realizedPL)
            PositionUtil.processTransaction(this.position, transaction);
        }

        // add the amount to the corresponding cashBalance
        this.cashBalance = this.cashBalance + transaction.getValue();

        logger.debug("executed transaction: " + transaction);

    }

}
