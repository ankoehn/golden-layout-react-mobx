package ak.simulator.entity.trade;

import ak.simulator.enumeration.Side;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

/**
 * Base Class for all Order Types
 */
@AllArgsConstructor
public abstract class Order {

    @Getter @Setter
    private Side side;
    @Getter @Setter
    private long quantity;

    @Override
    public String toString() {
        return "Order [side=" + this.side + ", quantity=" + this.quantity + "]";
    }

}
