package ak.simulator.simulation;

import ak.simulator.entity.Position;
import ak.simulator.entity.trade.MarketOrder;

import ak.simulator.enumeration.Side;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


public class SimulatorTest {

    private Simulator simulator;

    @BeforeEach
    public void before() {

        this.simulator = new SimulatorImpl();
    }

    @Test
    public void test() {

        this.simulator.setCashBalance(1000);

        this.simulator.setCurrentPrice(10.0);

        MarketOrder order1 = new MarketOrder(Side.BUY, 10);

        this.simulator.sendOrder(order1);

        Position position = this.simulator.getPosition();
        Assertions.assertEquals(10, position.getQuantity());

        double cashBalance = this.simulator.getCashBalance();
        Assertions.assertEquals(900.00, cashBalance, 0.01);

        this.simulator.setCurrentPrice(20.0);

        MarketOrder order2 = new MarketOrder(Side.SELL, 10);

        this.simulator.sendOrder(order2);

        position = this.simulator.getPosition();
        Assertions.assertEquals(0, position.getQuantity());
        Assertions.assertEquals(100, position.getRealizedPL(), 0.01);

        cashBalance = this.simulator.getCashBalance();
        Assertions.assertEquals(1100.00, cashBalance, 0.01);
    }
}
