package ak.sirius.engine.module;

import ak.sirius.module.ModuleTestUtil;
import com.typesafe.config.ConfigFactory;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;


public class ModuleDefinitionTest extends ModuleTestUtil {

    @Test
    public void testModuleDefinition() {
        // get the module definition for the {@link TestModule1}
        final ModuleDefinition moduleDefinition = ModuleDefinition.forType("test_mod_1");

        assertNotNull(moduleDefinition);
        assertEquals(TestModule1.class, moduleDefinition.getModuleClass());
        assertTrue(moduleDefinition.isConsumer());
        assertTrue(moduleDefinition.isProducer());

        // create a new instance of the module
        IModule module = moduleDefinition.newInstance("TEST_MOD", ConfigFactory.empty(), context);
        assertNotNull(module);
    }
}