package ak.sirius.engine.module;

import ak.sirius.event.EventWrapper;
import ak.sirius.util.ConfigUtil;
import com.typesafe.config.Config;

@Module("test_mod_2")
public class TestModule2 extends DublexModule<TestModule2.TestModule2Config> {

    @SuppressWarnings("unused")
    public TestModule2(String name, Config config, ProducerModuleContext context) {
        this(name, ConfigUtil.toBean(config, TestModule2.TestModule2Config.class), context);
    }

    @SuppressWarnings("unused")
    public TestModule2(String name, TestModule2.TestModule2Config config, ProducerModuleContext context) {
        super(name, config, context);
    }

    @Override
    protected void onData(EventWrapper event) {}

    @Override
    protected void startProcessing() {}

    public static class TestModule2Config extends DublexModule.DublexModuleConfig {}
}
