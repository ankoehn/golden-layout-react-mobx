package ak.sirius.engine.module;

import ak.sirius.event.EventWrapper;
import ak.sirius.util.ConfigUtil;
import com.typesafe.config.Config;

@Module("test_mod_1")
public class TestModule1 extends DublexModule<TestModule1.TestModule1Config> {

    @SuppressWarnings("unused")
    public TestModule1(String name, Config config, ProducerModuleContext context) {
        this(name, ConfigUtil.toBean(config, TestModule1.TestModule1Config.class), context);
    }

    @SuppressWarnings("unused")
    public TestModule1(String name, TestModule1.TestModule1Config config, ProducerModuleContext context) {
        super(name, config, context);
    }

    @Override
    protected void onData(EventWrapper event) {}

    @Override
    protected void startProcessing() {}

    public static class TestModule1Config extends DublexModule.DublexModuleConfig {}
}
