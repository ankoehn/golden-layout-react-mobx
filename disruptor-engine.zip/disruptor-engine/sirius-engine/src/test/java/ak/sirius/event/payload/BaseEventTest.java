package ak.sirius.event.payload;

import ak.sirius.event.EventWrapper;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static ak.sirius.event.EventType.ENGINE_STARTED;

public class BaseEventTest {

    private BaseEvent event;

    @BeforeEach
    public void setUp() {
        event = new BaseEventWrapper();
    }

    @Test
    public void getWrapper() {
        final EventWrapper eventWrapper = event.getWrapper();

        assertEquals(ENGINE_STARTED, eventWrapper.getEventType());
        assertEquals(event, eventWrapper.getPayload());
    }

    /** Makes {@link BaseEvent} not abstract */
    private static class BaseEventWrapper extends BaseEvent {

        protected BaseEventWrapper() {
            super(ENGINE_STARTED);
        }
    }
}