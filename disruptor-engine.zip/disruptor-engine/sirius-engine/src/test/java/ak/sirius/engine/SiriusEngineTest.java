package ak.sirius.engine;

import ak.sirius.util.ConfigUtil;
import com.typesafe.config.Config;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class SiriusEngineTest {

    @Test
    public void testSiriusEngine() {
        final Config config = ConfigUtil.loadConfig("Sirius").getConfig("inputs");

        // create Sirius engine with included IQueue engine
        final IEngine siriusEngine = SiriusEngine.newInstance("SiriusTest", config);
        assertNotNull(siriusEngine);

        // start the engine
        siriusEngine.start();

        // stop the engine
        siriusEngine.stop();
    }

}