package ak.sirius;

import org.junit.jupiter.api.Test;

public class SiriusAppTest {

    @Test
    public void testSiriuApp() {
        // test the Sirius App integration
        SiriusApp.main(new String[]{});

        // when no exception was thrown then it works =)
    }
}