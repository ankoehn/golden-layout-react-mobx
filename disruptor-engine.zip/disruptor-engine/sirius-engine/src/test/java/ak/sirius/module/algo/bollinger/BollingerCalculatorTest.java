package ak.sirius.module.algo.bollinger;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class BollingerCalculatorTest {

    @Test
    public void testCalculator() {
        final BollingerCalculator.BollingerCalculatorConfig config =
                new BollingerCalculator.BollingerCalculatorConfig();
        config.setLength(5);
        config.setDeviations(2);

        final IBollingerCalculator calculator = new BollingerCalculator(config);

        BollingerIndicator bollingerIndicator;

        bollingerIndicator = calculator.update(25.5);
        assertNull(bollingerIndicator);

        calculator.update(26.75);
        calculator.update(27.0);
        bollingerIndicator = calculator.update(26.5);
        assertNull(bollingerIndicator); // still null because length is defined as 5

        bollingerIndicator = calculator.update(27.25);
        assertNotNull(bollingerIndicator);

        assertEquals(27.80830459735946D, bollingerIndicator.getUpper(), 0D);
        assertEquals(26.6D, bollingerIndicator.getMiddle(), 0D);
        assertEquals(25.391695402640543D, bollingerIndicator.getLower(), 0D);
    }
}