package ak.sirius.module;

import ak.sirius.engine.IEventDispatcher;
import ak.sirius.engine.module.ProducerModuleContext;
import ak.sirius.event.EventWrapper;

import static org.mockito.Mockito.*;

public abstract class ModuleTestUtil {

    /** Dispatcher spy */
    protected final IEventDispatcher<EventWrapper> spyDispatcher;

    /** Mocked producer context */
    protected final ProducerModuleContext context;

    public ModuleTestUtil() {
        spyDispatcher = spy(IEventDispatcher.class);

        context = mock(ProducerModuleContext.class);
        when(context.getEventDispatcher()).thenReturn(spyDispatcher);
    }
}
