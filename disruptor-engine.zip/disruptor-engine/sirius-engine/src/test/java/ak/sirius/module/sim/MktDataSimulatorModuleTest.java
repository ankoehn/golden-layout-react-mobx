package ak.sirius.module.sim;

import ak.sirius.event.EventWrapper;
import ak.sirius.event.payload.MarketDataEvent;
import ak.sirius.module.ModuleTestUtil;
import org.junit.jupiter.api.Test;

import static ak.sirius.event.EventType.ENGINE_STARTED;
import static ak.sirius.event.EventType.MARKET_DATA;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;

public class MktDataSimulatorModuleTest extends ModuleTestUtil {

    @Test
    public void testModule() {
        // create config
        final MktDataSimulatorModule.MarketDataSimulatorConfig config =
                new MktDataSimulatorModule.MarketDataSimulatorConfig();
        config.setMktFile("EUR.USD.csv");

        final MktDataSimulatorModule module =
                new MktDataSimulatorModule("MKT_SIM", config, context);

        module.onStart();
        verifyNoMoreInteractions(spyDispatcher);

        // handle the ENGINE_STARTED callback
        module.getEventCallback().onData(new EventWrapper(ENGINE_STARTED, null));
        // after the module handled the ENGINE_STARTED it should read the market data from file and dispatch them
        verify(spyDispatcher).dispatch(new EventWrapper(MARKET_DATA,
                new MarketDataEvent("03.01.2001", 0.9507, 0.9262, 0.9569, 0.9271)));

        verify(spyDispatcher).dispatch(new EventWrapper(MARKET_DATA,
                new MarketDataEvent("04.01.2001", 0.9271, 0.9269, 0.9515, 0.9507)));

        verifyNoMoreInteractions(spyDispatcher);

        module.onStop();
        verifyNoMoreInteractions(spyDispatcher);
    }
}