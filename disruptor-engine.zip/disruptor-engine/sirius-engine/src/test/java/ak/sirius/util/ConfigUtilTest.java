package ak.sirius.util;

import com.typesafe.config.Config;
import org.junit.jupiter.api.Assertions;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ConfigUtilTest {

    @Test
    public void testLoadExistingConfig() {
        final Config config = ConfigUtil.loadConfig("TestApp1");

        assertNotNull(config);
        assertEquals("Test", config.getString("testString"));
    }

    @Test
    public void testLoadNotExistingConfig() {
        RuntimeException thrown = Assertions.assertThrows(RuntimeException.class, () -> {
            ConfigUtil.loadConfig("NotExistingConfig");
        });

        Assertions.assertEquals("Config file NotExistingConfig not found. Can not continue...", thrown.getMessage());
    }

    @Test
    public void testToBean() {
        final Config config = ConfigUtil.loadConfig("TestApp2");
        final TestConfig configAsBean = ConfigUtil.toBean(config, TestConfig.class);

        assertEquals("TestApp2", configAsBean.getName());

        assertEquals(2, configAsBean.getNumbers().size());
        assertEquals("ONE", configAsBean.getNumbers().get(1));
        assertEquals("TWO", configAsBean.getNumbers().get(2));

        assertEquals("default", configAsBean.getDefaultedString());
    }

    private static class TestConfig {
        private String name;
        public String getName() { return name; }

        private Map<Integer, String> numbers;
        public Map<Integer, String> getNumbers() { return numbers; }

        private String defaultedString = "default";
        public String getDefaultedString() { return defaultedString; }
    }
}