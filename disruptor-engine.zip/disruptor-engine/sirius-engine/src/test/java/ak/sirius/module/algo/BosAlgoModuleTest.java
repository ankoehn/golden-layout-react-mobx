package ak.sirius.module.algo;

import ak.sirius.event.EventWrapper;
import ak.sirius.event.payload.MarketDataEvent;
import ak.sirius.event.payload.OrderEvent;
import ak.sirius.event.payload.SimPxUpdateEvent;
import ak.sirius.module.ModuleTestUtil;
import ak.sirius.module.algo.bollinger.BollingerIndicator;
import ak.sirius.module.algo.bollinger.IBollingerCalculator;
import org.junit.jupiter.api.Test;

import static ak.sirius.event.EventType.ENGINE_STARTED;
import static ak.simulator.enumeration.Side.BUY;
import static ak.simulator.enumeration.Side.SELL;
import static org.mockito.Mockito.*;

public class BosAlgoModuleTest extends ModuleTestUtil {

    @Test
    public void testModule() {
        // Config of the module
        final BosAlgoModule.BosAlgoConfig config = new BosAlgoModule.BosAlgoConfig();

        // Bollinger Calculator spy
        final IBollingerCalculator calculator = mock(IBollingerCalculator.class);

        final BosAlgoModule module =
                new BosAlgoModule("BOS", config, context, calculator);

        module.onStart();
        verifyNoMoreInteractions(spyDispatcher);

        // handle the ENGINE_STARTED callback
        module.getEventCallback().onData(new EventWrapper(ENGINE_STARTED, null));
        verifyNoMoreInteractions(spyDispatcher);

        double mockedPx = 2.4;
        when(calculator.update(anyDouble())).thenReturn(new BollingerIndicator(7.5, 5, 2.5));
        module.getEventCallback().onData(new MarketDataEvent("01.01.19", mockedPx, mockedPx, mockedPx ,mockedPx).getWrapper());
        verify(spyDispatcher).dispatch(new SimPxUpdateEvent(mockedPx).getWrapper()); // sim px update
        verifyNoMoreInteractions(spyDispatcher);
        reset(spyDispatcher);

        // go LONG, close px change from 2.4 -> 2.2 and bollinger lower band is 2.3
        mockedPx = 2.2;
        when(calculator.update(anyDouble())).thenReturn(new BollingerIndicator(7.2, 4.5, 2.3));
        module.getEventCallback().onData(new MarketDataEvent("01.01.19", mockedPx, mockedPx, mockedPx,mockedPx).getWrapper());
        verify(spyDispatcher).dispatch(new SimPxUpdateEvent(mockedPx).getWrapper()); // sim px update
        verify(spyDispatcher).dispatch(new OrderEvent(config.getQty(), 0D, BUY).getWrapper()); // LONG
        verifyNoMoreInteractions(spyDispatcher);
        reset(spyDispatcher);

        // close prev opened LONG, close px change from 2.2 -> 4.3 and bollinger middle band is 4
        mockedPx = 4.3;
        when(calculator.update(anyDouble())).thenReturn(new BollingerIndicator(5.5, 4, 1.5));
        module.getEventCallback().onData(new MarketDataEvent("01.01.19", mockedPx, mockedPx, mockedPx,mockedPx).getWrapper());
        verify(spyDispatcher).dispatch(new SimPxUpdateEvent(mockedPx).getWrapper()); // sim px update
        verify(spyDispatcher).dispatch(new OrderEvent(config.getQty(), 0D, SELL).getWrapper()); // CLOSE POSITION
        verifyNoMoreInteractions(spyDispatcher);
        reset(spyDispatcher);

        // go SHORT, close px change from 4.3 -> 8.0 and bollinger lower band is 7
        mockedPx = 8.0;
        when(calculator.update(anyDouble())).thenReturn(new BollingerIndicator(7.0, 4.0, 1.0));
        module.getEventCallback().onData(new MarketDataEvent("01.01.19", mockedPx, mockedPx, mockedPx,mockedPx).getWrapper());
        verify(spyDispatcher).dispatch(new SimPxUpdateEvent(mockedPx).getWrapper()); // sim px update
        verify(spyDispatcher).dispatch(new OrderEvent(config.getQty(), 0D, SELL).getWrapper()); // SHORT
        verifyNoMoreInteractions(spyDispatcher);
        reset(spyDispatcher);

        // close prev opened SHORT, close px change from 8.0 -> 4.9 and bollinger middle band is 5
        mockedPx = 4.9;
        when(calculator.update(anyDouble())).thenReturn(new BollingerIndicator(8.0, 5.0, 2.0));
        module.getEventCallback().onData(new MarketDataEvent("01.01.19", mockedPx, mockedPx, mockedPx,mockedPx).getWrapper());
        verify(spyDispatcher).dispatch(new SimPxUpdateEvent(mockedPx).getWrapper()); // sim px update
        verify(spyDispatcher).dispatch(new OrderEvent(config.getQty(), 0D, BUY).getWrapper()); // CLOSE POSITION
        verifyNoMoreInteractions(spyDispatcher);
        reset(spyDispatcher);
    }
}