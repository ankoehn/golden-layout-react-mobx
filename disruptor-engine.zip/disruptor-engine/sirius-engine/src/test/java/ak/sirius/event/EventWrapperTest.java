package ak.sirius.event;

import ak.sirius.event.payload.OrderEvent;

import static ak.sirius.event.EventType.ORDER;
import static ak.simulator.enumeration.Side.BUY;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class EventWrapperTest {

    private EventWrapper eventWrapper;

    @BeforeEach
    public void setUp() {
        eventWrapper = new EventWrapper(ORDER, new OrderEvent(100, 0, BUY));
    }


    @Test
    public void copy() {
        final EventWrapper copy = new EventWrapper();

        assertNull(copy.getEventType());
        assertNull(copy.getPayload());

        copy.copy(eventWrapper);

        assertNotNull(copy.getEventType());
        assertNotNull(copy.getPayload());
        assertEquals(eventWrapper, copy);
    }

    @Test
    public void clear() {
        assertNotNull(eventWrapper.getEventType());
        assertNotNull(eventWrapper.getPayload());

        eventWrapper.clear();

        assertNull(eventWrapper.getEventType());
        assertNull(eventWrapper.getPayload());
    }
}