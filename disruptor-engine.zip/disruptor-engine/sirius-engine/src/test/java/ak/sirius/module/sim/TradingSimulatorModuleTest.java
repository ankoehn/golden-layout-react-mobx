package ak.sirius.module.sim;

import ak.simulator.enumeration.Direction;
import ak.sirius.event.EventWrapper;
import ak.sirius.event.payload.OrderEvent;
import ak.sirius.event.payload.SimPxUpdateEvent;
import ak.sirius.module.ModuleTestUtil;
import ak.simulator.simulation.Simulator;
import ak.simulator.simulation.SimulatorImpl;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import static ak.sirius.event.EventType.ENGINE_STARTED;
import static ak.sirius.event.EventType.ORDER;
import static ak.simulator.enumeration.Side.BUY;
import static ak.simulator.enumeration.Side.SELL;
import static org.mockito.Mockito.verifyNoMoreInteractions;

public class TradingSimulatorModuleTest extends ModuleTestUtil {

    @Test
    public void testModule() {
        // create config
        final TradingSimulatorModule.TradingSimulatorConfig config =
                new TradingSimulatorModule.TradingSimulatorConfig();

        // Create Simulator to inject in to the module
        final Simulator simulator = new SimulatorImpl();

        final TradingSimulatorModule module =
                new TradingSimulatorModule("TRD_SIM", config, context, simulator);

        module.onStart();
        verifyNoMoreInteractions(spyDispatcher);

        // handle the ENGINE_STARTED callback
        module.getEventCallback().onData(new EventWrapper(ENGINE_STARTED, null));
        verifyNoMoreInteractions(spyDispatcher);
        assertEquals(config.getCashBalance(), simulator.getCashBalance(), 0D);
        assertNull(simulator.getPosition());

        module.getEventCallback().onData(new SimPxUpdateEvent(10D).getWrapper());
        // BUY market order
        module.getEventCallback().onData(new OrderEvent(100000L, 0D, BUY).getWrapper());
        verifyNoMoreInteractions(spyDispatcher);
        assertEquals(0D, simulator.getCashBalance(), 0D);
        assertEquals(1000000D, simulator.getPosition().getCost(), 0D);
        assertEquals(100000, simulator.getPosition().getQuantity());
        assertEquals(Direction.LONG, simulator.getPosition().getDirection());

        // close the prev buy order
        module.getEventCallback().onData(new EventWrapper(ORDER, new OrderEvent(100000L, 0, SELL)));
        verifyNoMoreInteractions(spyDispatcher);
        assertEquals(1000000D, simulator.getCashBalance(), 0D);
        assertEquals(0D, simulator.getPosition().getCost(), 0D);
        assertEquals(0L, simulator.getPosition().getQuantity());
        assertEquals(Direction.FLAT, simulator.getPosition().getDirection());

        // new sell order with the dif qty
        module.getEventCallback().onData(new EventWrapper(ORDER, new OrderEvent(50000L, 0D, SELL)));
        verifyNoMoreInteractions(spyDispatcher);
        assertEquals(1500000D, simulator.getCashBalance(), 0D);
        assertEquals(-500000D, simulator.getPosition().getCost(), 0D);
        assertEquals(-50000, simulator.getPosition().getQuantity());
        assertEquals(Direction.SHORT, simulator.getPosition().getDirection());

        // close the prev sell order
        module.getEventCallback().onData(new EventWrapper(ORDER, new OrderEvent(50000L, 0, BUY)));
        verifyNoMoreInteractions(spyDispatcher);
        assertEquals(1000000D, simulator.getCashBalance(), 0D);
        assertEquals(0D, simulator.getPosition().getCost(), 0D);
        assertEquals(0L, simulator.getPosition().getQuantity());
        assertEquals(Direction.FLAT, simulator.getPosition().getDirection());

        module.onStop();
        verifyNoMoreInteractions(spyDispatcher);
    }
}