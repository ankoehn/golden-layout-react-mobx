package ak.sirius.event;

public enum EventType {
    /** Engine Started event: there is no payload class! */
    ENGINE_STARTED,

    /** Market Data event: {@link ak.sirius.event.payload.MarketDataEvent} */
    MARKET_DATA,

    /** Order event: {@link ak.sirius.event.payload.OrderEvent} */
    ORDER,

    /** Simulator Price Update Event: {@link ak.sirius.event.payload.SimPxUpdateEvent} */
    SIM_PX_UPDATE;
}
