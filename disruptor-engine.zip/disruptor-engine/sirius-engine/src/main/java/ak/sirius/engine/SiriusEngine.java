package ak.sirius.engine;

import ak.sirius.engine.module.IConsumer;
import ak.sirius.engine.module.IModule;
import ak.sirius.engine.module.ModuleDefinition;
import ak.sirius.engine.module.ProducerModuleContext;
import ak.sirius.event.EventType;
import ak.sirius.event.EventWrapper;
import ak.sirius.util.ConfigUtil;
import com.typesafe.config.Config;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Copyright 2019, Andreas Köhn - All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of Andreas Köhn.
 * Dissemination of this information or modification and reproduction of this material is strictly forbidden unless
 * prior written permission is obtained from Andreas Köhn (an.koehn@gmail.com).
 *
 */
@RequiredArgsConstructor
public class SiriusEngine implements IEngine {

    private final IQueue<EventWrapper> queue;
    private final List<IModule> modules;

    public void start() {
        if (queue != null) {
            queue.start();
        }

        modules.forEach(IModule::onStart);

        sendInitialEvent();
    }

    public void stop() {
        modules.forEach(IModule::onStop);
    }

    /**
     * Send the initial event to move all the modules into their processing processing thread
     */
    private void sendInitialEvent() {
        queue.getEventDispatcher().dispatch(new EventWrapper(EventType.ENGINE_STARTED, null));
    }

    public static IEngine newInstance(String engineName, Config config) {
        return newInstance(engineName, ConfigUtil.toBean(config, EngineConfig.class));
    }

    public static IEngine newInstance(String engineName, EngineConfig engineConfig) {
        int numConsumers = 0;
        int numProducers = 0;
        final Map<String, ModuleDefinition> nameToModuleDefinition = new HashMap<>();

        for (final Map.Entry<String, Config> entry : engineConfig.modules.entrySet()) {
            final String moduleInstanceName = entry.getKey();
            final String type = entry.getValue().getString("type");
            final ModuleDefinition moduleDefinition = ModuleDefinition.forType(type);

            if (moduleDefinition == null)
                throw new RuntimeException(String.format("Module with the type %s not found", type));

            nameToModuleDefinition.put(moduleInstanceName, moduleDefinition);
            if (moduleDefinition.isProducer())
                numProducers++;
            if (moduleDefinition.isConsumer())
                numConsumers++;
        }

        if (numConsumers == 0)
            throw new IllegalArgumentException("Zero consumers");
        if (numProducers == 0)
            throw new IllegalArgumentException("Zero producers");


        final List<IModule> modules = new ArrayList<>();
        final List<IEventCallback<EventWrapper>> eventCallbacks = new ArrayList<>();

        @SuppressWarnings("unchecked")
        IQueue<EventWrapper> queue = new DisruptorQueue(EventWrapper::new, engineName, eventCallbacks, engineConfig.disruptor);
        @SuppressWarnings("unchecked")
        IEventDispatcher<EventWrapper> eventProducer = queue.getEventDispatcher();

        for (Map.Entry<String, Config> entry : engineConfig.modules.entrySet()) {
            final String moduleInstanceName = entry.getKey();
            final Config moduleInstanceConfig = entry.getValue();
            final ModuleDefinition moduleDefinition = nameToModuleDefinition.get(moduleInstanceName);

            final ProducerModuleContext inputFullModuleContext = new ProducerModuleContext(eventProducer);
            final IModule moduleInstance = moduleDefinition.newInstance(moduleInstanceName, moduleInstanceConfig, inputFullModuleContext);

            if (moduleDefinition.isConsumer()) {
                @SuppressWarnings("unchecked") final IConsumer consumer = (IConsumer) moduleInstance;
                final IEventCallback<EventWrapper> eventCallback = consumer.getEventCallback();
                eventCallbacks.add(eventCallback);
            }
            modules.add(moduleInstance);
        }

        return new SiriusEngine(queue, modules);
    }

    @Data
    public static class EngineConfig {
        private DisruptorQueue.DisruptorConfig disruptor;
        private Map<String, Config> modules;
    }
}
