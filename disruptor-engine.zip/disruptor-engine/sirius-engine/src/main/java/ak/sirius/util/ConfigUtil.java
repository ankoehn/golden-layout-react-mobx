package ak.sirius.util;


import com.google.gson.*;
import com.typesafe.config.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.lang.reflect.Type;
import java.net.URL;

public class ConfigUtil {

    private static final Logger log = LogManager.getLogger(ConfigUtil.class);

    /** Gson instance for the deserialization */
    private static final Gson GSON;

    static {
        final GsonBuilder gsonBuilder = new GsonBuilder();
        gsonBuilder.registerTypeAdapter(Config.class, new ConfigDeserializer());
        GSON = gsonBuilder.create();
    }

    /**
     * Deserialize the given config to a bean of the given class and type
     *
     * @param config config to convert
     * @param clazz  class for the deserialization
     * @param <T>    type for the deserialization
     * @return deserialize bean
     * @throws ConfigException in case the deserialize failed
     */
    public static <T> T toBean(final Config config, final Class<T> clazz) throws ConfigException {
        final T bean;
        try {
            bean = GSON.fromJson(config.root().render(ConfigRenderOptions.defaults()), clazz);
        } catch (final JsonSyntaxException e) {
            throw new ConfigException.Parse(config.origin(), String.format("Can't parse to %s : \n%s", clazz, config.root().render(ConfigRenderOptions.defaults())), e);
        }

        return bean;
    }

    /**
     * Load the config file fro the resources folder.
     * The name of the file is defined as {@code appName}.conf
     *
     * @return loaded {@link Config}
     */
    public static Config loadConfig(String appName) {
        final URL configFileUrl = ConfigUtil.class.getClassLoader().getResource(String.format("%s.conf", appName));

        if(configFileUrl == null){
            throw new RuntimeException(String.format("Config file %s not found. Can not continue...", appName));
        }

        final Config config =
                ConfigFactory.parseURL(configFileUrl, ConfigParseOptions.defaults().setAllowMissing(false)).resolve();
        log.info("Config {} : \n{}",
                config.origin().description(),
                config.root().render(ConfigRenderOptions.defaults().setOriginComments(false).setComments(false)));
        return config;
    }

    /**
     * Deserializer for {@link Config}
     */
    private static class ConfigDeserializer implements JsonDeserializer<Config> {

        @Override
        public Config deserialize(final JsonElement json, final Type typeOfT, final JsonDeserializationContext context) throws JsonParseException {
            return ConfigFactory.parseString(json.toString(), ConfigParseOptions.defaults().setSyntax(ConfigSyntax.JSON));
        }
    }
}
