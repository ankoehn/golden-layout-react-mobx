package ak.sirius.engine.module;

import ak.sirius.engine.IEventCallback;
import ak.sirius.engine.IEventDispatcher;
import ak.sirius.event.EventWrapper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * A DublexModule is an abstract sim that implements the logic for the producer and consumer.
 *
 * @param <T> type of the configuration
 */
public abstract class DublexModule<T extends DublexModule.DublexModuleConfig> implements IModule, IProducer, IConsumer {

    private static final Logger log = LogManager.getLogger(DublexModule.class);

    /** Name of the sim */
    protected final String name;

    /** The configuration of the sim */
    protected final T config;

    /** IEvent dispatcher */
    protected final IEventDispatcher<EventWrapper> dispatcher;

    @SuppressWarnings("unused")
    public DublexModule(String name, T config, ProducerModuleContext<EventWrapper> context) {
        this.name = name;
        this.config = config;

        this.dispatcher = context.getEventDispatcher();
    }

    @Override
    public void onStart() { log.info("Starting module {}", name); }

    @Override
    public void onStop() {
        log.info("Stopping module {}", name);
    }

    @Override
    public IEventCallback<EventWrapper> getEventCallback() {
        return event -> {
            switch (event.getEventType()) {
                case ENGINE_STARTED:
                    this.onEngineStarted();
                    break;
                default:
                    this.onData(event);
                    break;
            }
        };
    }

    /**
     * Handle the event
     *
     * @param event to handle
     */
    protected abstract void onData(EventWrapper event);

    /**
     * Start the processing. This is executed within the modules own thread.
     */
    protected abstract void startProcessing();

    /** Run when the engine is started */
    private void onEngineStarted() {
        Thread.currentThread().setName(name);
        this.startProcessing();
    }

    public static class DublexModuleConfig {}
}
