package ak.sirius.event.payload;

import ak.sirius.event.EventType;
import ak.simulator.enumeration.Side;

import java.util.Objects;

public class OrderEvent extends BaseEvent {

    /** Quantity of the order, is positive and finite  */
    private final long qty;
    public long getQty() { return qty; }

    /** Price of the order positive -> limit order, 0 -> market order */
    private final double price;
    public double getPrice() { return price; }

    /** Side of the order BUY or SELL */
    private final Side side;
    public Side getSide() { return side; }

    public OrderEvent(long qty, double price, Side side) {
        super(EventType.ORDER);

        this.qty = qty;
        this.price = price;
        this.side = side;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        OrderEvent that = (OrderEvent) o;
        return qty == that.qty &&
                Double.compare(that.price, price) == 0 &&
                side == that.side;
    }

    @Override
    public int hashCode() {
        return Objects.hash(qty, price, side);
    }

    @Override
    public String toString() {
        return "OrderEvent{" +
                "qty=" + qty +
                ", price=" + price +
                ", side=" + side +
                '}';
    }
}
