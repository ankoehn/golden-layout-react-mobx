package ak.sirius.engine.module;

import com.typesafe.config.Config;
import io.github.lukehutch.fastclasspathscanner.FastClasspathScanner;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Map;

/**
 * Module definition contains all the information collected during the package scan to
 * create dynamically modules based on the provided configuration file.
 */
public class ModuleDefinition {

    private static final Logger log = LogManager.getLogger(ModuleDefinition.class);

    /** Package to scann for the modules */
    public static final String SEARCH_PACKAGE = "ak.sirius";

    /** Module container to store all the modules found in the package {@code SEARCH_PACKAGE} */
    private static final Map<String, ModuleDefinition> MODULE_DEFINITIONS = new HashMap<>();

    /*
      Scan the package {@code SEARCH_PACKAGE} for the modules (classes annotated with {@link Module}).
      Create a {@link ModuleDefinition} for each found sim and store it in the {@code MODULE_DEFINITIONS} container.
     */
    static {
        new FastClasspathScanner(SEARCH_PACKAGE)
                .scan()
                .getNamesOfClassesWithAnnotation(Module.class)
                .forEach(moduleClassName -> {
                    final Class<?> moduleClass;
                    try {
                        moduleClass = Class.forName(moduleClassName);
                    } catch (final ClassNotFoundException ex) {
                        throw new RuntimeException(ex);
                    }
                    final ModuleDefinition moduleDefinition = new ModuleDefinition(moduleClass);
                    final String moduleKey = moduleDefinition.getModuleType().toUpperCase();
                    if (MODULE_DEFINITIONS.containsKey(moduleKey))
                        throw new RuntimeException(String.format("Two modules with the same moduleType '%s' and '%s'", MODULE_DEFINITIONS.get(moduleKey), moduleDefinition));
                    MODULE_DEFINITIONS.put(moduleKey, moduleDefinition);
                });
        log.info("Available modules: {}", MODULE_DEFINITIONS);
    }

    /** Class of the sim */
    private final Class<?> moduleClass;
    public Class<?> getModuleClass() { return moduleClass; }

    /** Producer marker */
    private final boolean producer;
    public boolean isProducer() { return producer; }

    /** Consumer marker */
    private final boolean consumer;
    public boolean isConsumer() { return consumer; }

    /** The unique string type of the sim */
    private final String moduleType;
    public String getModuleType() { return moduleType; }

    private ModuleDefinition(final Class<?> cl) {
        moduleClass = cl;
        producer = IProducer.class.isAssignableFrom(moduleClass);
        consumer = IConsumer.class.isAssignableFrom(moduleClass);
        final String moduletype = cl.getAnnotation(Module.class).value();
        this.moduleType = moduletype.isEmpty() ? cl.getSimpleName() : moduletype;

        if (!producer && !consumer)
            throw new IllegalArgumentException(String.format("ModuleDefinition %s is not a producer or consumer", this));
    }

    /** Get the definition for the given type */
    public static ModuleDefinition forType(String type) {
        return MODULE_DEFINITIONS.get(type.toUpperCase());
    }

    /**
     * Create a new instance of the sim
     *
     * @param name         name of the sim
     * @param config       configuration of the sim
     * @param moduleContext context of the sim
     * @return instance of the sim
     */
    public IModule newInstance(String name, Config config, ModuleContext moduleContext) {
        try {
            if (isProducer()) {
                return (IModule) getModuleClass()
                        .getDeclaredConstructor(String.class, Config.class, ProducerModuleContext.class)
                        .newInstance(name.intern(), config, moduleContext);
            } else {
                return (IModule) getModuleClass()
                        .getDeclaredConstructor(String.class, Config.class, ModuleContext.class)
                        .newInstance(name.intern(), config, moduleContext);
            }
        } catch (InstantiationException | IllegalAccessException | InvocationTargetException | NoSuchMethodException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public String toString() { return moduleClass.getSimpleName(); }
}
