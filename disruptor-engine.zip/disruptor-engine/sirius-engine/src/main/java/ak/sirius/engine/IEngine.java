package ak.sirius.engine;

public interface IEngine {

    /** Start the engine */
    void start();

    /** Stop the engine */
    void stop();
}
