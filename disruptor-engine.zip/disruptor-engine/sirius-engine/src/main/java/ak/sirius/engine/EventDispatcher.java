package ak.sirius.engine;

import com.google.common.util.concurrent.ThreadFactoryBuilder;
import com.lmax.disruptor.RingBuffer;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class EventDispatcher<T extends IDispatchable<? super T>> implements IEventDispatcher<T> {

    private final RingBuffer<T> ringBuffer;
    private final Executor executor;

    EventDispatcher(RingBuffer<T> ringBuffer) {
        this.ringBuffer = ringBuffer;

        this.executor = Executors.newSingleThreadExecutor(new ThreadFactoryBuilder()
                .setDaemon(false)
                .setNameFormat("DISPATCHER")
                .build());
    }

    @Override
    public void dispatch(T event) {
        executor.execute(() -> {
            long sequence = ringBuffer.next();
            try {
                ringBuffer.get(sequence).copy(event);
            } finally {
                ringBuffer.publish(sequence);
            }
        });
    }
}
