package ak.sirius.engine.module;

public interface IModule {

    /** Run on start of the engine.
     * This method is executed from the main thread!
     */
    void onStart();

    /**
     * Run on stop of the engine.
     * This method is executed from the main thread!
     */
    void onStop();

}
