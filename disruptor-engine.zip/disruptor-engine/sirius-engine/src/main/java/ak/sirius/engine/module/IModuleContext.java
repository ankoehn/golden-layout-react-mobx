package ak.sirius.engine.module;

public interface IModuleContext {}
