package ak.sirius.module.sim;

import ak.sirius.engine.module.DublexModule;
import ak.sirius.engine.module.Module;
import ak.sirius.engine.module.ProducerModuleContext;
import ak.sirius.event.EventWrapper;
import ak.sirius.event.payload.MarketDataEvent;
import ak.sirius.util.ConfigUtil;
import com.typesafe.config.Config;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.util.LinkedList;
import java.util.List;

/**
 * MktDataSimulatorModule reads the market data from a csv file and dispatches them in the read order.
 * It ignores the first line assuming it is the header!
 */
@Module("mktsim")
public class MktDataSimulatorModule extends DublexModule<MktDataSimulatorModule.MarketDataSimulatorConfig> {

    private static final Logger log = LogManager.getLogger(MktDataSimulatorModule.class);

    @SuppressWarnings("unused")
    public MktDataSimulatorModule(String name, Config config, ProducerModuleContext context) {
        this(name, ConfigUtil.toBean(config, MarketDataSimulatorConfig.class), context);
    }

    @SuppressWarnings("unused")
    public MktDataSimulatorModule(String name, MarketDataSimulatorConfig config, ProducerModuleContext context) {
        super(name, config, context);
    }

    @Override
    protected void onData(EventWrapper eventWrapper) { /* do nothing */}

    @Override
    protected void startProcessing() {
        final String fileName = config.getMktFile();
        final URL fileUrl = this.getClass().getClassLoader().getResource(String.format("%s", fileName));

        if(fileUrl != null) {
            String csvFile = fileUrl.getFile();
            final List<String> lines = new LinkedList<>();

            try (final BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
                String line;
                while ((line = br.readLine()) != null) {
                    lines.add(line);
                }
            } catch (IOException e) {
                log.error(String.format("Could not read the file %s", fileName), e);
            }

            lines.remove(0); // remove the headers
            for(final String line : lines){
                try {
                    String[] mktData = line.split(config.getSplitBy());

                    final String date = mktData[0];
                    final double open = Double.parseDouble(mktData[1]);
                    final double low = Double.parseDouble(mktData[2]);
                    final double high = Double.parseDouble(mktData[3]);
                    final double close = Double.parseDouble(mktData[4]);;

                    final MarketDataEvent mktDataEvent = new MarketDataEvent(date, open, low, high, close);

                    dispatcher.dispatch(mktDataEvent.getWrapper());
                } catch (Exception e) {
                    log.error(String.format("Invalid market data: %s", line), e);
                }
            }
        } else {
            log.error("Could not find the file {}", fileName);
        }
    }

    /** Configuration of the market data simulator */
    @Data
    @EqualsAndHashCode(callSuper=false)
    public static class MarketDataSimulatorConfig extends DublexModule.DublexModuleConfig {
        private String mktFile;
        private String splitBy = ",";
    }
}
