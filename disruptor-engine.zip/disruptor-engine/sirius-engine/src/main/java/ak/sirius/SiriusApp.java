package ak.sirius;

import ak.sirius.engine.IEngine;
import ak.sirius.engine.SiriusEngine;
import ak.sirius.util.ConfigUtil;
import com.beust.jcommander.JCommander;
import com.beust.jcommander.Parameter;
import com.beust.jcommander.Parameters;
import com.typesafe.config.Config;
import lombok.Getter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class SiriusApp {
    private static final Logger log = LogManager.getLogger(SiriusApp.class);
    private static final String APP_NAME = "Sirius";

    private final AppConfig appConfig;

    private SiriusApp(String[] args) {
        CommandLineArguments commandLineArguments = parseArgs(args, new CommandLineArguments());
        Config config =
                commandLineArguments.getConfig() == null?
                        ConfigUtil.loadConfig(APP_NAME) :
                        ConfigUtil.loadConfig(commandLineArguments.getConfig());
        appConfig = ConfigUtil.toBean(config, AppConfig.class);
    }

    public static void main(String[] args) {
        new SiriusApp(args).start();
    }

    /** Start the application */
    private void start() {
        IEngine engine = SiriusEngine.newInstance(APP_NAME, appConfig.getInputs());
        engine.start();
    }

    /** Parse the arguments */
    private <T extends CommandLineArguments> T parseArgs(final String[] args, final T commandLineArguments) {
        final JCommander jCommander = new JCommander(commandLineArguments);

        try {
            jCommander.parse(args);
        } catch (final Exception e) {
            log.error(String.format("Error parsing command line: %s", e.getMessage()));
            jCommander.usage();
            System.exit(-1);
        }

        if (commandLineArguments.isHelp()) {
            jCommander.usage();
            System.exit(0);
        }

        return commandLineArguments;
    }

    @Parameters(separators = "=")
    private static class CommandLineArguments {
        @Parameter(names = {"-util", "-c"}, description = "Configuration file for the application")
        @Getter private String config;

        @Parameter(names = {"-help", "-h"}, help = true)
        @Getter private boolean help;
    }

    /** The main app configuration */
    private static class AppConfig {
        @Getter private Config inputs;
    }
}
