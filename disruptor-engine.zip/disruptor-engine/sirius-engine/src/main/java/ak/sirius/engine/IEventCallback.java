package ak.sirius.engine;

/**
 * Handles the events from the {@link com.lmax.disruptor.dsl.Disruptor}
 *
 * @param <T> type of the event
 */
public interface IEventCallback<T> {

    /** Handle the given event*/
    void onData(T event);
}
