package ak.sirius.module.algo.bollinger;

import lombok.Value;

@Value
public class BollingerIndicator {

    double upper;

    double middle;

    double lower;

}
