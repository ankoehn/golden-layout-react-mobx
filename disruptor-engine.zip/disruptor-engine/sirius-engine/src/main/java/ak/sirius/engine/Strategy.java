package ak.sirius.engine;

import com.lmax.disruptor.BlockingWaitStrategy;
import com.lmax.disruptor.BusySpinWaitStrategy;
import com.lmax.disruptor.WaitStrategy;
import com.lmax.disruptor.YieldingWaitStrategy;

import java.util.function.Supplier;

/** See: https://github.com/LMAX-Exchange/disruptor/wiki/Getting-Started */
public enum Strategy {
    BUSY_SPIN(BusySpinWaitStrategy::new),
    BLOCKING(BlockingWaitStrategy::new),
    YIELDING(YieldingWaitStrategy::new);

    public final Supplier<WaitStrategy> waitStrategy;

    Strategy(final Supplier<WaitStrategy> waitStrategy) {
        this.waitStrategy = waitStrategy;
    }
}
