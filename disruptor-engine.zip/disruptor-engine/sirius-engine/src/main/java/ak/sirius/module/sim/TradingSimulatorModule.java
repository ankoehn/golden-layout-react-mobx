package ak.sirius.module.sim;

import ak.sirius.engine.module.DublexModule;
import ak.sirius.engine.module.Module;
import ak.sirius.engine.module.ProducerModuleContext;
import ak.sirius.event.EventWrapper;
import ak.sirius.event.payload.OrderEvent;
import ak.sirius.event.payload.SimPxUpdateEvent;
import ak.sirius.util.ConfigUtil;
import ak.simulator.entity.trade.MarketOrder;
import ak.simulator.simulation.Simulator;
import ak.simulator.simulation.SimulatorImpl;
import com.typesafe.config.Config;
import lombok.Getter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import static ak.simulator.enumeration.Direction.FLAT;

/**
 * TradingSimulatorModule is a module wrapper for the provided {@link Simulator}.
 */
@Module("trdsim")
public class TradingSimulatorModule extends DublexModule<TradingSimulatorModule.TradingSimulatorConfig> {

    private static final Logger log = LogManager.getLogger(TradingSimulatorModule.class);

    private final Simulator simulator;

    @SuppressWarnings("unused")
    public TradingSimulatorModule(String name, Config config, ProducerModuleContext context) {
        this(name, ConfigUtil.toBean(config, TradingSimulatorConfig.class), context);
    }

    @SuppressWarnings("unused")
    public TradingSimulatorModule(String name, TradingSimulatorConfig config, ProducerModuleContext context) {
        this(name, config, context, new SimulatorImpl());
    }

    @SuppressWarnings("unused")
    public TradingSimulatorModule(String name, TradingSimulatorConfig config, ProducerModuleContext context, Simulator simulator) {
        super(name, config, context);
        this.simulator = simulator;
    }

    @Override
    public void onStart() {
        super.onStart();

        // initialize the simulator
        simulator.setCashBalance(config.getCashBalance());

        log.info("Simulator initiated with the cache balance {}", config.getCashBalance());
    }

    @Override
    protected void onData(EventWrapper eventWrapper) {
        switch (eventWrapper.getEventType()) {
            case ORDER:
                handleOrder((OrderEvent) eventWrapper.getPayload());
                break;
            case SIM_PX_UPDATE:
                handleSimPxUpdate((SimPxUpdateEvent) eventWrapper.getPayload());
            default:
                break;
        }
    }

    @Override
    protected void startProcessing() { /* nothing to do */}

    /** Handle the incoming order event */
    private void handleOrder(OrderEvent orderEvent) {
        if(orderEvent.getPrice() == 0) {
            final MarketOrder marketOrder = new MarketOrder(orderEvent.getSide(), orderEvent.getQty());
            simulator.sendOrder(marketOrder);
        } else {
            log.warn("Unsupported order type");
        }

        if(simulator.getPosition().getDirection() == FLAT) {
            log.info("Position Closed - Current Cash Balance is: {}", simulator.getCashBalance());
        }
    }

    /** Handle the incoming simulator price update) */
    private void handleSimPxUpdate(SimPxUpdateEvent simPxUpdateEvent) {
        simulator.setCurrentPrice(simPxUpdateEvent.getPx());
    }

    /** Configuration of the trading simulator */
    public static class TradingSimulatorConfig extends DublexModule.DublexModuleConfig {
        @Getter private double cashBalance = 1000000;
    }
}
