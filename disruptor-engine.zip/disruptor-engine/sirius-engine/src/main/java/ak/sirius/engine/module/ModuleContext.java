package ak.sirius.engine.module;

public class ModuleContext implements IModuleContext {}
