package ak.sirius.engine;

public interface IDispatchable<T> {
    void copy(T original);

    void clear();
}
