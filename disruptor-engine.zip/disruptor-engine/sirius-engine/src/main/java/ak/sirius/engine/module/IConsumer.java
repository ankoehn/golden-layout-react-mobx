package ak.sirius.engine.module;

import ak.sirius.engine.IDispatchable;
import ak.sirius.engine.IEventCallback;

public interface IConsumer<T extends IDispatchable<? super T>> {

    /**
     * Returns the event callback (event handler) of the consumer
     *
     * @return event callback
     */
    IEventCallback<T> getEventCallback();
}
