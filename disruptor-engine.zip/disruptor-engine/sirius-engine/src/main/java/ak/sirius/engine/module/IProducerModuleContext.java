package ak.sirius.engine.module;

import ak.sirius.engine.IDispatchable;
import ak.sirius.engine.IEventDispatcher;

public interface IProducerModuleContext<T extends IDispatchable<? super T>> extends IModuleContext {

    /** Returns the dispatcher of the producer */
    IEventDispatcher<T> getEventDispatcher();
}

