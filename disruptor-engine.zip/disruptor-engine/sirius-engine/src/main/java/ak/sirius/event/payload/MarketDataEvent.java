package ak.sirius.event.payload;

import ak.sirius.event.EventType;

import java.util.Objects;

public class MarketDataEvent extends BaseEvent {

    /** Date and Time*/
    private final String dateTime;
    public String getDateTime() { return dateTime; }

    /** Prices */
    private final double open;
    public double getOpen() { return open; }

    private final double low;
    public double getLow() { return low; }

    private final double high;
    public double getHigh() { return high; }

    private final double close;
    public double getClose() { return close; }

    public MarketDataEvent(String dateTime, double open, double low, double high, double close) {
        super(EventType.MARKET_DATA);

        this.dateTime = dateTime;
        this.open = open;
        this.low = low;
        this.high = high;
        this.close = close;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        MarketDataEvent that = (MarketDataEvent) o;
        return Double.compare(that.open, open) == 0 &&
                Double.compare(that.low, low) == 0 &&
                Double.compare(that.high, high) == 0 &&
                Double.compare(that.close, close) == 0 &&
                dateTime.equals(that.dateTime);
    }

    @Override
    public int hashCode() {
        return Objects.hash(dateTime, open, low, high, close);
    }

    @Override
    public String toString() {
        return "MarketDataEvent{" +
                "dateTime='" + dateTime + '\'' +
                ", open=" + open +
                ", low=" + low +
                ", high=" + high +
                ", close=" + close +
                '}';
    }
}
