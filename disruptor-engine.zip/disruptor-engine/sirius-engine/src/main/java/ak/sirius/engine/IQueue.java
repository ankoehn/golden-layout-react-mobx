package ak.sirius.engine;

/**
 * Queue engine to process the events
 *
 * @param <T> type of the event
 */
public interface IQueue<T extends IDispatchable<? super T>> extends IEngine {

    /** Returns the queue's dispatcher */
    IEventDispatcher getEventDispatcher();
}
