package ak.sirius.module.algo.bollinger;

public interface IBollingerCalculator {

    /**
     * Updates the calculator with the given price and return
     * the calculated {@link BollingerIndicator} or null if there are still
     * not enough data
     *
     * @param price to update the calculator with
     * @return calculated {@link BollingerIndicator} or null if there are still not enough data
     */
    BollingerIndicator update(double price);
}
