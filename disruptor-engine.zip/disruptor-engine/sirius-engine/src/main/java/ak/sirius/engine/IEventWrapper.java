package ak.sirius.engine;

/**
 * Wraps the event and the event type
 *
 * @param <P> payload type of the event
 * @param <T> event type
 */
public interface IEventWrapper<P, T> extends IDispatchable<IEventWrapper<P, T>> {

    /** Type of the event */
    T getEventType();

    /** Payload of the event */
    P getPayload();
}
