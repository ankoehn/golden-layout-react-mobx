package ak.sirius.module.algo;

import ak.sirius.engine.module.DublexModule;
import ak.sirius.engine.module.Module;
import ak.sirius.engine.module.ProducerModuleContext;
import ak.sirius.event.EventWrapper;
import ak.sirius.event.payload.MarketDataEvent;
import ak.sirius.event.payload.OrderEvent;
import ak.sirius.event.payload.SimPxUpdateEvent;
import ak.sirius.module.algo.bollinger.BollingerCalculator;
import ak.sirius.module.algo.bollinger.BollingerIndicator;
import ak.sirius.module.algo.bollinger.IBollingerCalculator;
import ak.sirius.util.ConfigUtil;
import com.typesafe.config.Config;
import lombok.Getter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import static ak.simulator.enumeration.Side.BUY;
import static ak.simulator.enumeration.Side.SELL;

@Module("bos")
public class BosAlgoModule extends DublexModule<BosAlgoModule.BosAlgoConfig> {

    private static final Logger log = LogManager.getLogger(BosAlgoModule.class);

    /** Bollinger Bands calculator */
    private final IBollingerCalculator bollingerCalculator;

    private final long qty;

    /** Internal state of the algo */

    private BollingerIndicator currentIndicator = null;

    private double lastClosePx = 0;
    private double currentClosePx = 0;

    private long position = 0;

    @SuppressWarnings("unused")
    public BosAlgoModule(String name, Config config, ProducerModuleContext context) {
        this(name, ConfigUtil.toBean(config, BosAlgoConfig.class), context);
    }

    @SuppressWarnings("unused")
    public BosAlgoModule(String name, BosAlgoConfig config, ProducerModuleContext context) {
        this(name, config, context, new BollingerCalculator(config.getBollinger()));
    }

    @SuppressWarnings("unused")
    public BosAlgoModule(String name, BosAlgoConfig config, ProducerModuleContext context, IBollingerCalculator bollingerCalculator) {
        super(name, config, context);

        this.qty = config.getQty();
        this.bollingerCalculator = bollingerCalculator;
    }

    @Override
    protected void onData(EventWrapper eventWrapper) {
        switch (eventWrapper.getEventType()) {
            case MARKET_DATA:
                handleMarketData((MarketDataEvent) eventWrapper.getPayload());
                break;
            default:
                break;
        }
    }

    @Override
    protected void startProcessing() {}

    /**
     * Handle market data and update the bollinger indicator state
     *
     * @param mktData market data to handle
     */
    private void handleMarketData(MarketDataEvent mktData) {
        final double closePx = mktData.getClose();

        /*
            TODO the Sirius Engine is designed (the same as the real world) in an asynchronous way.
                The assignment gives on the other hand the following structure:
                "import next price from csv -> update Bollinger band -> signal logic -> order handling". This is synchronous!
                I still wanted to move the simulator into its own module {@link TradingSimulatorModule}
                because in the reality there may be one provider for market data and another one for the trading api.
                To make sure the {@link TradingSimulatorModule} (basically a wrapper for the provided simulator) is
                synchronised with the BosAlgoModule, this algo module has to update it with the last close price
                NOT the {@link MktDataSimulatorModule}. Otherwise the simulator will be updated to quickly.
         */
        final SimPxUpdateEvent simPxUpdateEvent = new SimPxUpdateEvent(closePx);
        dispatcher.dispatch(simPxUpdateEvent.getWrapper());

        this.currentIndicator = bollingerCalculator.update(closePx);
        if(currentIndicator == null) {
            return;
        }

        // update the close price state
        lastClosePx = currentClosePx;
        currentClosePx = closePx;

        // do action if needed
        if(lastClosePx != 0 && currentClosePx != 0) {
            doAction();
        }
    }

    /** Do action SHORT, LONG or CLOSE the position if needed */
    private void doAction() {
        // go short or long if needed
        if(position == 0) {
            if(lastClosePx <= currentIndicator.getUpper() && currentClosePx > currentIndicator.getUpper()) {
                // Open a SHORT position
                dispatcher.dispatch(new OrderEvent(qty, 0D, SELL).getWrapper());
                position = -1 * qty;
            } else if(lastClosePx >= currentIndicator.getLower() && currentClosePx < currentIndicator.getLower()) {
                // Open a LONG position
                dispatcher.dispatch(new OrderEvent(qty, 0D, BUY).getWrapper());
                position = qty;
            }
        }

        // close position if needed
        if(position < 0 && lastClosePx >= currentIndicator.getMiddle() && currentClosePx < currentIndicator.getMiddle()) {
            // Close the SHORT position
            dispatcher.dispatch(new OrderEvent(qty, 0D, BUY).getWrapper());
            position = 0;
        } else if(position > 0 && lastClosePx <= currentIndicator.getMiddle() && currentClosePx > currentIndicator.getMiddle()) {
            // Close the LONG position
            dispatcher.dispatch(new OrderEvent(qty, 0D, SELL).getWrapper());
            position = 0;
        }
    }

    public static class BosAlgoConfig extends DublexModule.DublexModuleConfig {
        @Getter private BollingerCalculator.BollingerCalculatorConfig bollinger = new BollingerCalculator.BollingerCalculatorConfig();

        @Getter private long qty = 10000;
    }
}
