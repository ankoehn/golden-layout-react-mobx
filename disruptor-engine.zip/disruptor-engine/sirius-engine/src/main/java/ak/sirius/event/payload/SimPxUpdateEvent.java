package ak.sirius.event.payload;

import java.util.Objects;

import static ak.sirius.event.EventType.SIM_PX_UPDATE;

public class SimPxUpdateEvent extends BaseEvent {

    /** Price to update the simulator with */
    private double px;
    public double getPx() { return px; }

    public SimPxUpdateEvent(double px) {
        super(SIM_PX_UPDATE);

        this.px = px;
    }

    @Override
    public String toString() {
        return "SimPxUpdateEvent{" +
                "px=" + px +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SimPxUpdateEvent that = (SimPxUpdateEvent) o;
        return Double.compare(that.px, px) == 0;
    }

    @Override
    public int hashCode() {
        return Objects.hash(px);
    }
}
