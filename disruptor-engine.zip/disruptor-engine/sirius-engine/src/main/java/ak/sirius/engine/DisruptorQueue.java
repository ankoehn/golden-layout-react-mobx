package ak.sirius.engine;

import com.google.common.util.concurrent.ThreadFactoryBuilder;
import com.lmax.disruptor.EventHandler;
import com.lmax.disruptor.TimeoutException;
import com.lmax.disruptor.dsl.Disruptor;
import com.lmax.disruptor.dsl.ProducerType;
import lombok.Getter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.List;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Supplier;

/** Implementation of the {@link IQueue} using the LMAX {@link Disruptor} */
public class DisruptorQueue<T extends IDispatchable<? super T>> implements IQueue<T> {

    private static final Logger log = LogManager.getLogger(DisruptorQueue.class);

    private static final AtomicInteger ID = new AtomicInteger();

    /** Configuration of the disruptor */
    private final DisruptorConfig disruptorConfig;

    /** LMAX {@link Disruptor} */
    private final Disruptor<T> disruptor;

    /** Evtent dispatcher */
    private final IEventDispatcher<T> eventDispatcher;

    /** List of the {@link IEventCallback} to call on each new event on the {@link com.lmax.disruptor.RingBuffer} */
    private final List<IEventCallback<T>> eventCallbacks;

    DisruptorQueue(Supplier<T> typeConstructor,
                   String engineName,
                   List<IEventCallback<T>> eventCallbacks,
                   DisruptorConfig disruptorConfig) {

        this.disruptorConfig = disruptorConfig;

        final ThreadFactory threadFactory = new ThreadFactoryBuilder()
                .setDaemon(false)
                .setNameFormat(String.format("%s-%d-pool-%%d", engineName, ID.incrementAndGet()))
                .build();

        this.eventCallbacks = eventCallbacks;

        // create the disruptor
        this.disruptor = new Disruptor<>(typeConstructor::get, disruptorConfig.getSize(),
                threadFactory, disruptorConfig.getProducerType(), disruptorConfig.getStrategy().waitStrategy.get());

        // create event dispatcher using the {@code disruptor}'s {@link RingBuffer}
        this.eventDispatcher = new EventDispatcher<>(this.disruptor.getRingBuffer());
    }

    @Override
    public void start() {
        log.info("Start the disruptor queue for {} callbacks", eventCallbacks.size());
        final EventHandler[] eventHandlers = eventCallbacks.stream()
                .map(callback -> (EventHandler<T>) (event, sequence, endOfBatch) -> callback.onData(event))
                .toArray(EventHandler[]::new);

        disruptor.handleEventsWith(eventHandlers)
                // clear the event after all modules handled it
                .then((EventHandler<T>) (event, sequence, endOfBatch) -> event.clear());

        disruptor.start();
    }

    @Override
    public void stop() {
        try {
            disruptor.shutdown(disruptorConfig.getShutdownTimeout(), TimeUnit.MILLISECONDS);
        } catch (TimeoutException e) {
            log.error(String.format("Can't stop disruptor nicely, waited %s", disruptorConfig.getShutdownTimeout()));
            disruptor.halt();
        }
    }

    @Override
    public IEventDispatcher getEventDispatcher() {
        return this.eventDispatcher;
    }

    /** Configuration of the disruptor */
    public static class DisruptorConfig {
        @Getter private int size = 512;

        @Getter private ProducerType producerType = ProducerType.MULTI;

        @Getter private Strategy strategy = Strategy.BLOCKING;

        @Getter private long shutdownTimeout = 5000;
    }
}