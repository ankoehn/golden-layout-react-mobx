package ak.sirius.event.payload;

import ak.sirius.event.EventType;

public interface IEvent {
    EventType getEventType();
}
