package ak.sirius.event.payload;

import ak.sirius.event.EventType;
import ak.sirius.event.EventWrapper;

/** Base event logic is implemented here */
public abstract class BaseEvent implements IEvent {

    private final EventType eventType;

    @Override
    public EventType getEventType() {
        return eventType;
    }

    protected BaseEvent(EventType eventType) {
        this.eventType = eventType;
    }

    /** Make an {@link EventWrapper} from {@code this} */
    public EventWrapper getWrapper(){
        return new EventWrapper(this.eventType, this);
    }
}
