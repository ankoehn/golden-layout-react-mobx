package ak.sirius.engine.module;

public interface IProducer {}
