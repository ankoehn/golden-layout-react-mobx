package ak.sirius.module.algo.bollinger;

import lombok.Data;

/**
 * Bollinger Bands Calculator
 *
 * Source: http://www.great-trades.com/Help/bollinger%20bands%20calculation.htm
 */
public class BollingerCalculator implements IBollingerCalculator {
    /** See {@link IndexSupplier} */
    private final IndexSupplier indexSupplier;

    /** Prices to calculate the Bollinger Bands */
    private final double[] prices;

    /** Deviations to calculate the Bollinger Bands */
    private final double deviations;

    /** In case this is true the calculator has enough data to start the calculation */
    private boolean active = false;

    public BollingerCalculator(BollingerCalculatorConfig config) {
        this.prices = new double[config.getLength()];
        this.indexSupplier = new IndexSupplier(config.getLength() - 1);

        this.deviations = config.getDeviations();
    }

    @Override
    public BollingerIndicator update(double price) {
        final int i = indexSupplier.next();
        prices[i] = price;

        if(!active && i == prices.length - 1) { active = true; } // enough data collected

        if(active) {
            return calculateBollingerIndicator();
        } else {
            return null;
        }
    }

    /** Calculate the bollinger indicator  */
    private BollingerIndicator calculateBollingerIndicator() {
        final double sma = calculateSimpleMovingAverage();
        final double deviationValue = calculateDeviationValue(sma);

        double upper = sma + (deviations * deviationValue);
        double lower = sma - (deviations * deviationValue);
        return new BollingerIndicator(upper, sma, lower);
    }

    /** Calculate the deviation value for the given sma */
    private double calculateDeviationValue(double sma) {
        double sum = 0;
        for(double p : prices) {
            sum += StrictMath.pow(p - sma, 2);
        }

        return StrictMath.sqrt(sum/prices.length);
    }

    /** Calculate the simple moving average */
    private double calculateSimpleMovingAverage() {
        double sum = 0;
        for(double p : prices) { sum += p; }

        return sum/prices.length;
    }

    /** Provides the pointer of the price array to override with the new updated price (the oldest value) */
    private static class IndexSupplier {
        private final int max;
        private int current = 0;

        public IndexSupplier(int max) { this.max = max; }

        /** Get the next integer to access the array */
        public int next() {
            try {
                return current;
            } finally {
                if(current == max) { current = 0; }
                else { current++; }
            }
        }
    }

    @Data
    public static class BollingerCalculatorConfig {
        private int length = 30;
        private double deviations = 2;
    }
}
