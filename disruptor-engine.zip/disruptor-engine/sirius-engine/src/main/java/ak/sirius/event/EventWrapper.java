package ak.sirius.event;

import ak.sirius.engine.IEventWrapper;
import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@EqualsAndHashCode
@ToString
public class EventWrapper implements IEventWrapper<Object, EventType> {

    /** Type of the event */
    private EventType eventType;

    /** Payload of the event */
    private Object payload;

    @Override
    public void copy(IEventWrapper<Object, EventType> original) {
        this.eventType = original.getEventType();
        this.payload = original.getPayload();
    }

    @Override
    public void clear(){
        eventType = null;
        payload = null;
    }
}
