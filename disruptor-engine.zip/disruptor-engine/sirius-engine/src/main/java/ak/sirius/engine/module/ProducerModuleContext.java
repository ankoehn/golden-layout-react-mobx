package ak.sirius.engine.module;


import ak.sirius.engine.IDispatchable;
import ak.sirius.engine.IEventDispatcher;

public class ProducerModuleContext<T extends IDispatchable<? super T>> extends ModuleContext implements IProducerModuleContext<T> {

    private final IEventDispatcher<T> eventDispatcher;
    @Override public IEventDispatcher<T> getEventDispatcher() {
        return eventDispatcher;
    }

    public ProducerModuleContext(IEventDispatcher<T> eventDispatcher) {
        this.eventDispatcher = eventDispatcher;
    }
}
