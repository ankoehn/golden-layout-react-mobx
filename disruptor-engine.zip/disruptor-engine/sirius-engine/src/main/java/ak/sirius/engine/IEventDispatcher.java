package ak.sirius.engine;

/**
 * IEvent dispatcher to dispatch the events via the {@link com.lmax.disruptor.dsl.Disruptor}
 *
 * @param <T> type of the event to dispatch
 */
public interface IEventDispatcher<T extends IDispatchable<? super T>> {

    /**
     * Dispatch the given event
     *
     * @param event event to dispatch
     */
    void dispatch(T event);
}
